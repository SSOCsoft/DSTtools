--------------------------------------------------------
How to use this set of SPINOR data reduction routines:
--------------------------------------------------------

The data reduction has 4 different steps:

1. Get the file information of the data in the source directory. This will eventually be used for a fully automatic data reduction, but currently it is necessary to manually identify the file types (flat field (ff), calibration (cal), observation (obs)).

2. Construct all gaintables from the ff and dc data.

3. Get the polarimetric instrument response X from the instrumental cal. data.

4. Reduce the obs with the gaintable, dc, X matrix, T matrix.

Additional optional steps are to:

5. Create overview maps, gif images, and text files with header information for inclusion in the web-based archive (static html pages), and update the main archive page accordingly. This is no necessary part of the data reduction, but helps keeping overview of an observation campaign. You can start your own archive. Note that it only shows an overview of the data, the data themselves are not part of the archive.

6. To remove interference fringes in QUV.

--------------------------------------------------------

All intermediate steps (average dc/ff, gaintable, pol. cal. measurements, X-matrices) are saved to IDL save files to be able to re-run only some part of the data reduction faster. Final reduced obs data is written out as unformatted floating numbers with an additional save file that contains the necessary information on array dimensions.

spinor_soft_help.html contains the html-version of the program headers with parameters, keywords, and a short description of each routine (created with mk_html_help.pro, IDL-implemented, see IDL help).
 
--------------------------------------------------------

! Important ! 

1. All file variables ending in "_file" (gain_file, dark_file, cal_file) refer to the number of the >base< file in the INPUT directory as listed in the text file created in step 1 above. I.e. gain_file = 2 means: use the third base file in the input directory as flat field data. 

All variables ending in "index" (gainindex, darkindex) refer to the number of that >type< of file in the OUTPUT directory. I.e. gainindex = 2 means: use the third gain save file in the output directory.

And sorry, obsindex refers to the file number in the INPUT directory (no rule without exemption).

2a) You have to open the routine laodct.pro and change the filenames in

restore,'/home/cbeck/savefiles/ct41.sav'

and 

restore,'/home/cbeck/savefiles/ct41_wowhite.sav'

to  ~/spinor_soft/ct41.sav and ~/spinor_soft/ct41_wowhite.sav or wherever you put the routines/savefiles.

2b) Change the default telescope matrix file at the start of the routine spinor_obs.pro.

3. The routines to be used are:

spinor_ff.pro, spinor_cal.pro, spinor_obs.pro

! Important !

--------------------------------------------------------

Example of call to routines:

--------------------------------------------------------

-----------------------------------------------------------
pro cal_spinor_854_290713

pp = 1
if pp eq 1 then begin
   input_dir = '/scr2/lvtt/t985_july_29/'
   output_dir = '/data/cbeck/obs2013/290713/reduced_8542_spinor/'
   spinor_ff,input_dir=input_dir,output_dir=output_dir,/plt,flat_file = 0.,/full_beam,sspeed = 10.,yyrange =[60,490,550,970]

endif

pp = 1
if pp eq 1 then begin
   input_dir = '/scr2/lvtt/t985_july_29/'
   output_dir = '/data/cbeck/obs2013/290713/reduced_8542_spinor/'
   tmat_save = '/home/cbeck/laptop_teneriffa/telcal_DST/Tmatrix_May2010_4708-14125.idl'
   spinor_cal,cal_file = 0,retard = 88.,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/plt,tmat_save = tmat_save

endif

pp = 1
if pp eq 1 then begin

   tmat_save = '/home/cbeck/laptop_teneriffa/telcal_DST/Tmatrix_May2010_4708-14125.idl'
   input_dir = '/scr2/lvtt/t985_retry/'
   output_dir = '/data/cbeck/obs2013/290713/reduced_8542_spinor/'
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 0.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause
   pos_lines = [240,412]
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 1.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 2.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 3.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 4.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 5.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 6.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 7.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 8.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines

endif

sscale = 0.3

output_dir = '/data/cbeck/obs2013/290713/reduced_8542_spinor/'
inpath = output_dir
outpath = '/export/cbeck/SPINOR_archive/2013/290713/'
generate_spinor_archive_files,inpath = inpath, outpath = outpath,twice = 4,wavelen = 1083.,pollimit = .04,/check_lines,sscale = sscale

inpath = outpath

spinor_create_html,filepath = inpath

spinor_create_mainhtml

stop

end

-----------------------------------------------------------

Detailed explanation of options:

-----------------------------------------------------------

1. Gain table/spinor_ff.pro (for all wavelength ranges): 

Example:

spinor_ff,flat_file = 1,/plt,input_dir = input_dir,output_dir = output_dir,int_limit = .1

a) automatic detection of beam locations can be overruled manually by providing values (overlapping beams). See keyword yyrange.

b) Change of the value int_limit can make automatic detection work properly.

c) When repeating the gaintable calculation, /no_av skips averaging the files again.

d) It is recommended to run with /plt (plotting switched on), even if it requires the user to acknowledging some steps. /nopause suppress all stop/pause commands, but still displays all plots.

Actions to be taken interactively:

e) Determination of location of spectral lines. An inverted line profile will be displayed (upside down). Click on two spectral lines (see the manual for a detailed explanation), of which the left one has to be suitable for aligning spectra and the right one delimits the wavelength range used for optimizing the gain table.

Effects of choice: 

The first line that is clicked on will be used to determine line-core positions, derive spectral shifts, etc. It does not matter if it is solar or telluric.

The range from the 30 pixel to the blue of the leftt line to 30 pixels to the red of the right line is used to minimize spectral residuals in the gain table. Range must include at least one spectral line. The more lines are included, the better the method works, but the longer it takes.

f) Upper/lower beam will be aligned to each other for every slit. 

i) Break conditions:

Run with /plt the first time. The determined locations of the beams in x and y will be indicated. If beams overlap or value of int_limit is badly chosen, beam edges will be determined wrong. Cut out beams are displayed at the end. 
g1) Interrupt with Control-C, change int_limit to higher/lower value (steps of 0.05 recommended), try again.
g2) If automatic method doesn't work from int_limit = 0.05 to 0.5, provide values manually. Set yyrange to e.g. [50,500,550,1000].

-----------------------------------------------------------

2. Getting the X-matrix spinor_cal.pro, all wavelengths

Example:

spinor_cal,cal_file = 0,retard = 88.,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/plt,tmat_save = tmat_save

a) averaged dc and one gain table has to be created before. The gain table is not used, but the restore command is still in the routine because the beam locations a stored in the gain table save file.

b) Only value to set is the retardance of the calibration unit with the suggested values 88 deg for 630, 82 deg for 1083, and 116 for 1565. See manual for more values.

c) For each slit, a separate X-matrix is calculated for n_separations (default: 10) along the slit. Spatially/spectrally resolved matrices can be calculated as well for test purpose (set keyword spat_res = [nx,ny] for nx/ny regions in x/y; can be that this keyword won't work correctly).

-----------------------------------------------------------

3. Reduce observational data with spinor_obs.pro:

Example:

   tmat_save = '/home/cbeck/laptop_teneriffa/telcal_DST/Tmatrix_May2010_4708-14125.idl'   
   pos_lines =  [242.85388, 412.21443]
   spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 1.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.,tmat_save = tmat_save,/nopause,pos_lines = pos_lines

a) In case there are no suited dc, ff, gain, cal files available from the same day, copy these files from another directory to the output directory, or provide these files explicitly (see keywords ccal_file, flat_file in spinor_obs.pro).

b) It is recommended to provide the wavelength in Angstroem explicitly each time, because the headers could be wrong. The value is used in the polarimetric telescope model.

c) Same as 1. f) above: click on two spectral lines to mark them. Line positions provided by the keyword pos_lines overrule manual selection (will be skipped then) to reduce data of one day without any more interaction required.

Effects of choice: 

The line positions are used to define the continuum wavelength range for I->QUV cross-talk correction. The range is set to a range between the two lines marked. If a solar line with Zeeman signal is inside the corresponding range, it can offset the I->QUV correction. The line-core position of the leftmost line marked is used for subpixel alignment of the two beams.

For the rest of the keywords, see the html help.

--------------------------------------------------------

4. Reduced data can be viewed with 

spinor_view,'.... .dat'

but it requires the files from generate_spinor_archive_files.pro as well.

--------------------------------------------------------

Multi-wl example of call to routines

--------------------------------------------------------
pro cal_spinor_1083_120513

pp = 1
if pp eq 1 then begin
   input_dir = '/data/cbeck/t976/12_may_2013/flir_10830/'
   output_dir = '/data/cbeck/obs2013/120513/reduced_1083_spinor/'
   spinor_ff,input_dir=input_dir,output_dir=output_dir,/plt,flat_file = 0.

   input_dir = '/data/cbeck/t976/12_may_2013/sarnoff_8542/'
   output_dir = '/data/cbeck/obs2013/120513/reduced_8542_spinor/'
   spinor_ff,input_dir=input_dir,output_dir=output_dir,/plt,flat_file = 0.,/no_av,int_limit = .2,/full_beam

   input_dir = '/data/cbeck/t976/12_may_2013/flir_15648/'
   output_dir = '/data/cbeck/obs2013/120513/reduced_1565_spinor/'
   spinor_ff,input_dir=input_dir,output_dir=output_dir,/plt,flat_file = 0.

endif

pp = 1
if pp eq 1 then begin

tmat_save = '/home/cbeck/laptop_teneriffa/telcal_DST/Tmatrix_May2010_4708-14125.idl'

input_dir = '/data/cbeck/t976/12_may_2013/flir_10830/'
output_dir = '/data/cbeck/obs2013/120513/reduced_1083_spinor/'
spinor_cal,cal_file = 0,retard = 83.,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/plt,wavelength = 10830.,tmat_save = tmat_save

;cchitotal = fltarr(200,10)
;rettotal = fltarr(200)
;for k = 0.,199 do begin & rettotal(k) =  50.+k*.5 & spinor_cal,cal_file = 0,retard = 50.+k*.5,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/no_av,cchi = cchi,/nverbose & cchitotal(k,*) = cchi & print,k & endfor
;plot,rettotal,total(cchitotal,2)
;stop

input_dir = '/data/cbeck/t976/12_may_2013/flir_15648/'
output_dir = '/data/cbeck/obs2013/120513/reduced_1565_spinor/'
spinor_cal,cal_file = 0,retard = 105.,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/plt,wavelength = 15650.,tmat_save = tmat_save

;cchitotal = fltarr(200,10)
;rettotal = fltarr(200)
;for k = 0.,199 do begin & rettotal(k) =  50.+k*.5 & spinor_cal,cal_file = 0,retard = 50.+k*.5,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/no_av,cchi = cchi,/nverbose & cchitotal(k,*) = cchi & print,k & endfor
;window,0
;!p.multi = 0
;plot,rettotal,total(cchitotal,2)
;stop

input_dir = '/data/cbeck/t976/12_may_2013/sarnoff_8542/'
output_dir = '/data/cbeck/obs2013/120513/reduced_8542_spinor/'
spinor_cal,cal_file = 0,retard = 88.,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/plt,tmat_save = tmat_save,wavelength = 8542.

;cchitotal = fltarr(200,10)
;rettotal = fltarr(200)
;for k = 0.,199 do begin & rettotal(k) =  50.+k*.5 & spinor_cal,cal_file = 0,retard = 50.+k*.5,input_dir = input_dir,output_dir = output_dir,darkindex = 0,gainindex = 0,/no_av,cchi = cchi,/nverbose & cchitotal(k,*) = cchi & print,k & endfor
;window,0
;!p.multi = 0
;plot,rettotal,total(cchitotal,2)

endif

pp = 1
if pp eq 1 then begin

input_dir = '/data/cbeck/t976/12_may_2013/flir_10830/'
output_dir = '/data/cbeck/obs2013/120513/reduced_1083_spinor/'
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 0.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 10830.
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 1.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 10830.

input_dir = '/data/cbeck/t976/12_may_2013/flir_15648/'
output_dir = '/data/cbeck/obs2013/120513/reduced_1565_spinor/'
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 0.,input_dir = input_dir,output_dir = output_dir,cont_wl = [230,250],calindex = 0,wavelength = 15650.,spec_line = [180,210]
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 1.,input_dir = input_dir,output_dir = output_dir,cont_wl = [230,250],calindex = 0,wavelength = 15650.,spec_line = [180,210]

input_dir = '/data/cbeck/t976/12_may_2013/sarnoff_8542/'
output_dir = '/data/cbeck/obs2013/120513/reduced_8542_spinor/'
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 0.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.
spinor_obs,/plt,gainindex = 0,darkindex = 0,angle = 0.,obsindex = 1.,input_dir = input_dir,output_dir = output_dir,calindex = 0,wavelength = 8542.

endif

sscale = 0.3

output_dir = '/data/cbeck/obs2013/120513/reduced_8542_spinor/'
inpath = output_dir
outpath = '/export/cbeck/SPINOR_archive/2013/120513/'
generate_spinor_archive_files,inpath = inpath, outpath = outpath,twice = 4,wavelen = 1083.,pollimit = .01,/check_lines,sscale = sscale

output_dir = '/data/cbeck/obs2013/120513/reduced_1565_spinor/'
inpath = output_dir
outpath = '/export/cbeck/SPINOR_archive/2013/120513/'
generate_spinor_archive_files,inpath = inpath, outpath = outpath,twice = 4,wavelen = 1565.,pollimit = .01,/check_lines,sscale = sscale

output_dir = '/data/cbeck/obs2013/120513/reduced_1083_spinor/'
inpath = output_dir
outpath = '/export/cbeck/SPINOR_archive/2013/120513/'
generate_spinor_archive_files,inpath = inpath, outpath = outpath,twice = 4,wavelen = 1083.,pollimit = .01,/check_lines,sscale = sscale

inpath = outpath
spinor_create_html,filepath = inpath
spinor_create_mainhtml

stop






end

--------------------------------------------------------
