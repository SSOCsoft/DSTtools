--------------------------------------------------------
How to use this set of FIRS data reduction routines:
--------------------------------------------------------

The data reduction has 4 different steps:

1. Get the file information of the data in the source directory. This will eventually be used for a fully automatic data reduction, but currently it is necessary to manually identify the file types (dark current (dc), flat field (ff), calibration (cal), observation (obs)).

2. Construct all gain tables from the ff and dc data.
2a. If needed, average all additional dc measurements that were not taken together with a ff measurement.

3. Get the polarimetric instrument response X from the instrumental cal. data.

4. Reduce the obs with the gain table, dc, X matrix, T matrix.

An additional final optional step is to:

5. Create overview maps, gif images, and text files with header information for inclusion in the web-based archive (static html pages), and update the main archive page accordingly. This is no necessary part of the data reduction, but helps keeping overview of an observation campaign. You can start your own archive. Note that it only shows an overview of the data, the data themselves are not part of the archive.

--------------------------------------------------------

All intermediate steps (average dc/ff, gain table, pol. cal. measurements, X-matrices) are saved to IDL save files to be able to re-run only some part of the data reduction faster. Final reduced obs data is written out as unformatted floating numbers with an additional save file that contains the necessary information on array dimensions.

firs_soft.html contains the html-version of the program headers with parameters, keywords, and a short description of each routine (created with mk_html_help.pro, IDL-implemented, see IDL help).

firs_ret.pdf is a collection of retardance values for the instrumental calibration unit at the DST. 

--------------------------------------------------------

! Important ! 

1. All file variables ending in "_file" (gain_file, dark_file, cal_file) refer to the number of the >base< file in the INPUT directory as listed in the text file created in step 1 above. I.e. gain_file = 2 means: use the third base file in the input directory as flat field data. 

All variables ending in "index" (gainindex, darkindex) refer to the number of that >type< of file in the OUTPUT directory. I.e. gainindex = 2 means: use the third gain save file in the output directory.

And sorry, obsindex refers to the file number in the INPUT directory (no rule without exemption).

2. You have to open the routine laodct.pro and change the filenames in

restore,'/home/cbeck/savefiles/ct41.sav'

and 

restore,'/home/cbeck/savefiles/ct41_wowhite.sav'

to  ~/firs_soft/ct41.sav and ~/firs_soft/ct41_wowhite.sav or wherever you put the routines/savefiles.

3. The routines to be used for 630 nm are:

get_firs_dataprop.pro, firs_630_ff.pro, firs_cal.pro, firs_630_obs.pro

For any of the IR lines it is:

get_firs_dataprop.pro, firs_1083_ff.pro, firs_cal.pro, firs_1565_obs.pro.

! Important !

--------------------------------------------------------

Example of call to routines (630 nm example at the end of the text):

--------------------------------------------------------

-----------------------------------------------------------

pro cal_200113_1083

; directory to input raw data
input_dir = '/export/cbeck/obs2013/200113/firs/'

; directory for output data
output_dir = '/export/cbeck/obs2013/200113/firs/reduced_200113/'

; change location of save file with data information if you do not have write
; permission in input_dir

; change_save = '/export/cbeck/obs2012/20121209/firs2/' 


pp = 1
if pp eq 1 then begin

; get the information on the files in the input_dir. Reads fits headers of observations, creates text file with summary.

get_firs_dataprop,input_dir,change_save =change_save

; check output text file for the numbers of flat, dc, cal, observations. Numbers provided below for all _file variables must correspond to the base file numbers in the text file created by get_firs_dataprop. 

stop

endif

; coding for eventual automatic reduction, ignore
; 16 cal   2 map  1 ff 0 dc

; 2013 01 20
types1 = [2,1,0,2,2,1,0,2,1,0,2,16,16,2,2,1,0]

pp = 1
if pp eq 1 then begin

; get gaintable from ff file 1 and dc file 2 (numbers as in text file from above)
; int_limit is used in finding beams automatically

firs_1083_ff,change_save = change_save,flat_file = 1,dark_file = 2,/plt,input_dir = input_dir,output_dir = output_dir,int_limit = .1

; get gaintable from ff file 5 and dc file 6 (numbers as in text file from above)

firs_1083_ff,change_save = change_save,flat_file = 5,dark_file = 6,/plt,input_dir = input_dir,output_dir = output_dir,int_limit = .1

; get gaintable from ff file 8 and dc file 9 (numbers as in text file from above)

firs_1083_ff,change_save = change_save,flat_file = 8,dark_file = 9,/plt,input_dir = input_dir,output_dir = output_dir,int_limit = .1

; get instrument response matrix X

firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 11,darkindex= 2,change_save =change_save,theta_err = 5,flat_file = flat_file,retard = 82.

; repeat for second set of cals

firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 12,darkindex= 2,change_save =change_save ,theta_err = 5,flat_file = flat_file,theta_pol = 45.

endif


pp = 1
if pp eq 1 then begin

; use response function first from first set of cals.
cal_file =  11

; reduce obs file 0 with averaged dc 0 and gain table 0 and cal_file 11

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 0,gainindex = 0,change_save =change_save,obsindex =  0,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

; reduce obs file 3 with averaged dc 0 and gain table 0

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 0,gainindex = 0,change_save =change_save,obsindex =  3,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

; reduce obs file 4 with averaged dc 1 and gain table 1

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 1,gainindex = 1,change_save =change_save,obsindex =  4,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

; reduce obs file 7 with averaged dc 1 and gain table 1

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 1,gainindex = 1,change_save =change_save,obsindex =  7,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

; reduce obs file 13 with averaged dc 2 and gain table 2

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 2,gainindex = 2,change_save =change_save,obsindex =  13,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

; reduce obs file 14 with averaged dc 2 and gain table 2

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 2,gainindex = 2,change_save =change_save,obsindex =  14,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

endif

; create archive files and update archive. Archive structure is hardwired to FIRS_archive/year/ddmmyy/'. No guarantee if it works with another naming convention (could actually, but I'm not sure).

inpath = output_dir
outpath = '/export/cbeck/FIRS_archive/2013/200113/'

generate_firs_archive_files,inpath = inpath, outpath = outpath,twice = 4,wavelen = 1083.,pollimit = .03

inpath = outpath
firs_create_html,filepath = inpath

;  You will have to modify the default filename in firs_create_mainhtml or use the keyword "outfile" here. The (needed) graphics are included in the firs_soft/ directory, they have to be in the directory .../FIRS_archive/ then.

firs_create_mainhtml


stop


end

-----------------------------------------------------------

Detailed explanation of options:

-----------------------------------------------------------

1. Gain table/firs_630_ff.pro and firs_1083_ff.pro (for both IR wavelength ranges): 

Example:

firs_1083_ff,change_save = change_save,flat_file = 1,dark_file = 2,/plt,input_dir = input_dir,output_dir = output_dir,int_limit = .1


a) automatic detection of beam locations can be overruled manually by providing values (overlapping beams). See keywords yyrange, pickx in firs_630_ff.pro and firs_1083_ff.pro.

b) Change of the value int_limit can make automatic detection work properly.

c) In case additional dc measurements were taken, use the keyword /avdc_only to only average the dc without calculating a gain table.

d) When repeating the gaintable calculation, /no_av skips averaging the files again.

e) It is recommended to run with /plt (plotting switched on), even if it requires the user to acknowledging some steps.

Actions to be taken interactively:

f) Determination of location of spectral lines. An inverted line profile will be displayed (upside down). 

f1) For 630 nm data, click from left to right on 630.15 line core, 630.20, 630.25, 630.27. Suited wavelength ranges and line positions will be derived from the positions clicked on. No high precision in clicking needed, always some range around the core is used anyway (+-15 pixels or similar).

f2) For 1083 nm data, click on Si 1082.7, and the next solar/strong line to the red of He I 1083.

f3) For 1565 nm data, click on either 1564.8 and 1565.2 nm or include more line in the spectrum, if present.

f4) Effects of choice: 

The first line that is clicked on will be used to determine line-core positions, derive spectral shifts, etc. It does not matter if it is solar or telluric.

The range from the 30 pixel to the blue of the first line to 30 pixels to the red of the last line (IR data) or 3rd line (630 nm data), respectively, is used to minimize spectral residuals in the gain table. Range must include at least one spectral line. The more lines are included, the better the method works, but the longer it takes.

g) Upper/lower beam will be aligned to each other for every slit. If values for different slits differ too much, user will be prompted for providing an estimate of displacement. Usually only one out of n beams is off, take a value around the one of the others, e.g. shifts of 4 beams = -50 -53 -52 -10  -> enter -50.

h) Break conditions:

Run with /plt the first time. The determined locations of the beams in x and y will be indicated. If beams overlap or value of int_limit is badly chosen, beam edges will be determined wrong and number of slits will be wrong. Cut out beams are displayed at the end. 
g1) Interrupt with Control-C, change int_limit to higher/lower value (steps of 0.05 recommended), try again.
g2) If automatic method doesn't work from int_limit = 0.05 to 0.5, provide values manually. Set yyrange to e.g. [0,511,512,1022]*scale  (scale may be 1, 2 or 0.5, image is scaled to screen size for beam detection, thus it depends on hardware) and use keyword /pickx in IR data (VIS data up to now always worked in x). With /pickx, click on the left and right edge of each slit, going from left to right.

-----------------------------------------------------------

2. Getting the X-matrix firs_cal.pro, all wavelengths

Example:

firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 11,darkindex= 2,change_save =change_save,theta_err = 5,flat_file = flat_file,retard = 82.

a) averaged dc and one gaintable has to be created before. gaintable is not used in the end, but the restore command is still in the routine.

b) Only value to set is the retardance of the calibration unit with the suggested values 88 deg for 630, 82 deg for 1083, and 116 for 1565. See firs_ret.pdf for more values.

c) In case you have additional measurements corresponding to a Stokes vector input of +- QU, set keyword add_cal to the corresponding file numbers, e.g. add_cal = [10,11,12,13]. You can get the best value of retardance then with a short loop:

; create save files with observed values
firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 4,darkindex= 0,gainindex = 0,change_save =change_save ,theta_err = 5,flat_file = flat_file,add_cal = add_cal

; vary retardance and store chi^2 between +-QU input and corrected output (== should be again +-QU if X-matrix(retard) is good)
cchi_total = fltarr(200,4)

for iindex = 0.,199 do begin & retard = 50+iindex*.5 & firs_cal,input_dir =input_dir, output_dir = output_dir,cal_file = 4,darkindex= 0,gainindex = 0,change_save =change_save ,theta_err = 5,flat_file = flat_file,add_cal = add_cal,/no_av,retard = retard,/nverbose,cchi = cchi & cchi_total(iindex,*) = cchi & endfor

plot,50+findgen(200)*.5,cchi_total(*,0)

d) For each slit, a separate X-matrix is calculated. Spatially resolved matrices can be calculated as well for test purpose (set keyword spat_res = [nx,ny] for nx/ny regions in x/y).

-----------------------------------------------------------

3. Reduce observational data with firs_630_obs.pro, firs_1565_obs.pro (both IR wavelength ranges):

Example:

firs_1565_obs,/plt,input_dir = input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 1,gainindex = 1,change_save =change_save,obsindex =  4,tmat_save = '/home/cbeck/firs_soft/Tmatrix_May2010_4708-14125.idl',wavelength = 10830.

a) In case there are no suited dc, ff, gain, cal files available from the same day, copy these files from another directory to the output directory, or provide these files explicitly (see keywords ccal_file, flat_file in firs_630_obs.pro, firs_1565_obs.pro).

b) It is recommended to provide the wavelength in Angstroem explicitly each time, because the FIRS headers can be >wrong<; they are set manually in the FIRS control gui.

c) Same as 1. f) above: click on spectral lines to mark them. In this case, 

c1) for 630 nm data, click from left to right on 630.15 line core, 630.20, 630.25, 630.27. Suited wavelength ranges and line positions will be derived from the positions clicked on. No high precision in clicking needed, always some range around the core is used anyway (+-15 pixels or similar).

c2) For 1083 nm data, click on Si 1082.7 and He I 1083.

c3) For 1565 nm data, click on 1564.8 and 1565.2 nm. 

c4) Effects of choice: 

The line positions are used to define the continuum wavelength range for I->QUV cross-talk correction. The range is set to around 630.20 for 630 nm data, between 1564.8 and 1565.5 nm for 1565 nm data, and between Si 1082.7 and He 1083.3 nm for 1083 nm data. If a solar line with Zeeman signal is inside the corresponding range, it can offset the I->QUV correction.

For the rest of the keywords, see the html help.

--------------------------------------------------------

4. Reduced data can be viewed with 

firs_view,'.... .dat'

but it requires the files from generate_firs_archive_files.pro as well.

--------------------------------------------------------

630 nm example of call to routines

--------------------------------------------------------

pro cal_160413_630


input_dir = '/nfs/export/scr2/cbeck/obs2013/160413/firs1/'
output_dir = '/export/cbeck/obs2013/firs_april2013/160413_reduced_630/'
;spawn,'mkdir '+output_dir

change_save = '/export/cbeck/obs2013/firs_april2013/160413_reduced_630/' 

pp = 0
if pp eq 1 then begin
   get_firs_dataprop,input_dir,change_save =change_save
endif

; 16 cal   2 map  1 ff 0 dc

types1 = [2,2,2,2,0,1,2,2,1,0,16,16,16,16,16,0,2]

pp = 1
if pp eq 1 then begin

firs_630_ff,change_save = change_save,flat_file = 5,dark_file = 4,/plt,input_dir = input_dir,output_dir = output_dir,yyrange = [0,511,512,1022]

firs_630_ff,change_save = change_save,flat_file = 8,dark_file = 9,/plt,input_dir = input_dir,output_dir = output_dir,yyrange = [0,511,512,1022]

firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 10,darkindex= 1,gainindex = 1,change_save =change_save,theta_err = 5,retard = 88.

firs_cal,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = 11,darkindex= 1,gainindex = 1,change_save =change_save,theta_err = 5,retard = 88.,theta_pol = 45.

endif


pp = 1
if pp eq 1 then begin

cal_file = 10
tmat_save = '/home/cbeck/laptop_teneriffa/telcal_DST/Tmatrix_May2010_4708-14125.idl'

firs_630_obs,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 0,gainindex = 0,change_save =change_save,obsindex =  1,angle = 0,tmat_save = tmat_save

firs_630_obs,/plt,input_dir =input_dir, output_dir = output_dir,cal_file =  cal_file,darkindex= 0,gainindex = 0,change_save =change_save,obsindex =  2,angle = 0,tmat_save = tmat_save

firs_630_obs,/plt,input_dir =input_dir, output_dir = output_dir,cal_file = cal_file,darkindex= 0,gainindex = 0,change_save =change_save,obsindex =  3,angle = 0,tmat_save = tmat_save

firs_630_obs,/plt,input_dir =input_dir, output_dir = output_dir,cal_file =  cal_file,darkindex= 1,gainindex = 1,change_save =change_save,obsindex =  6,angle = 0,tmat_save = tmat_save

endif

inpath = output_dir
outpath = '/export/cbeck/FIRS_archive/2013/160413/'

generate_firs_archive_files,inpath = inpath, outpath = outpath,twice = 2,wavelen = 630.,pollimit = .01,wwidth = 3

inpath = outpath
firs_create_html,filepath = inpath
firs_create_mainhtml

stop


end

--------------------------------------------------------
